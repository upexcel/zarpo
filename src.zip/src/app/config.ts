export let config = {
    user_password : 5,
    api_url: "https://m.zarpo.com.br/afpc.php?path=",
    websiteId: 8,
    faceBook_AppId: 852541798134845,
    faceBook_AppName: 'zarpoApp',
    is_subscribed: 0
}

//#standup:
//1)TL9H*: bug- Device- ipad, For Pacotes product page, content tab-> At the end of the first content tab there is a link, connecting to the zarpo magazine, First issue, that need to click the link several times to get it working and second issue that on zarpo magazine page , there is no way for you to come back to the app.
//2)T1SS*: bug- Logout and turn off wifi and the launch the app. It should give no network screen instead of displaying the signin page.
//3)timezone correction