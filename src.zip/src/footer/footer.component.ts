//import {Page} from 'ionic-angular';
import {Component, OnInit, Input, OnChanges, Output, EventEmitter} from '@angular/core';


@Component({
    selector: "zarpo-footer",
    templateUrl: 'footer.html'
})

export class FooterComponent {


}


