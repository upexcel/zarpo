export class State{
    name:string;
    val:string;
}
export class User {
    email: string;
    password: string;
    name:string;
    surname:string;
    state:string;
}
export var STATE: State[] =  [
            {name: "Escolha seu estado", val: "-1"},
            {name: "Espírito Santo", val: "326"},
            {name: "Minas Gerais", val: "331"},
            {name: "Paraná", val: "334"},
            {name: "Rio de Janeiro", val: "337"},
            {name: "Rio Grande do Sul", val: "339"},
            {name: "Santa Catarina", val: "342"},
            {name: "São Paulo", val: "343"},
            {name: "Acre", val: "320"},
            {name: "Alagoas", val: "321"},
            {name: "Amapá", val: "322"},
            {name: "Amazonas", val: "323"},
            {name: "Bahia", val: "324"},
            {name: "Ceará", val: "325"},
            {name: "Distrito Federal", val: "346"},
            {name: "Espírito Santo", val: "326"},
            {name: "Goiás", val: "327"},
            {name: "Maranhão", val: "328"},
            {name: "Mato Grosso", val: "329"},
            {name: "Mato Grosso do Sul", val: "330"},
            {name: "Minas Gerais", val: "331"},
            {name: "Pará", val: "332"},
            {name: "Paraíba", val: "333"},
            {name: "Paraná", val: "334"},
            {name: "Pernambuco", val: "335"},
            {name: "Piauí", val: "336"},
            {name: "Rio de Janeiro", val: "337"},
            {name: "Rio Grande do Norte", val: "338"},
            {name: "Rio Grande do Sul", val: "339"},
            {name: "Rondônia", val: "340"},
            {name: "Roraima", val: "341"},
            {name: "Santa Catarina", val: "342"},
            {name: "São Paulo", val: "343"},
            {name: "Sergipe", val: "344"},
            {name: "Tocantins", val: "345"}
        ];